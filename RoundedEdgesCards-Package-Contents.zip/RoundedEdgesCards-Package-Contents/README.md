
# RoundedEdgesCards
### Created with [DeckSmith](https://rounds.thunderstore.io/package/willis81808/DeckSmith/)

*Still In Dev*
*pics coming soon*
This is just a small card pack meant for the rounded edges community that goes with the Mod pack with custom maps!
little broken 

## Cards


#### Draugur

Draugur

- Ammunition +12
- Damage -40%
- Reload Time -30%





#### ColdSnap

ColdSnap

- Projectiles +10
- Bursts +2
- Time Between Bullets +2.9 seconds





#### Devery

Devery

- Reload Time -15%
- Attack Speed -30%
- Damage +20%





#### Atticus

Atticus

- Damage +100%
- Health -10%
- Ammunition -2





#### Riacs

Riacs

- Health +30%
- Reload Time -20%
- Bullet Speed +40%





#### Reggin

Reggin

- Projectiles +5
- Ammunition +7





#### Sukuna

Sukuna

- Attack Speed +50%
- Damage +30%
- Health -20%





#### Rounded Edge

The Rounded Edge

- Damage +50%
- Health +30%
- Reload Time -10%
- Ammunition -1
- Projectiles +2
- Bounces +1





#### Edge

The Edge!?!

- Damage +20%
- Health -10%





#### Bouncy

All the bounces

- Bounces +10
- Ammunition -1
- Projectiles +2





#### Double Barrel Sniper

The double Barrel Snipper From Valorant

- Bullet Speed +100%
- Damage +60%
- Ammunition -2
- Projectiles +2
- Attack Speed +100%
- Reload Time +10%





#### Murph

Murph

- Damage +55%
- Health +30%
- Reload Time -10%





#### Round Trinket

You found a round trinket share this with your friends

- Damage +50%
- Projectiles +5
- Bursts +1
- Time Between Bullets +0.1 seconds
- Health -30%





#### Brrrrr

BRRRRRRRRR

- Attack Speed +65%
- Bullet Speed +60%
- Ammunition +7
- Damage -20%
- Reload Time -5%





#### More HP

GIVE ME HEALTH!!!!!!

- Health +45%





#### More HP II

GIVE ME HEALTH!!!!!!

- Health +65%





#### More HP III

GIVE ME HEALTH!!!!!!

- Health +100%





#### More HP IV

GIVE ME HEALTH!!!!!!

- Damage +140%





#### More HP V

GIVE ME HEALTH!!!!!!

- Health +200%





#### More DMG

GIVE ME DMG!

- Damage +40%





#### More DMG II

GIVE ME DMG!

- Damage +65%





#### More DMG III

GIVE ME DMG!

- Damage +100%





#### More DMG IV

GIVE ME DMG!

- Damage +125%





#### More DMG V

GIVE ME DMG!

- Damage +150%





#### Fast Mag

Faster Reloading

- Reload Time -30%





#### Fast Mags II

Even Faster Reloading

- Reload Time -50%





#### Faster Mags III

EVEN Faster Reloading!

- Reload Time -90%





#### The Founders

You have Became a founder now show your wrath

- Damage +50%
- Health +30%
- Ammunition +3
- Attack Speed -20%
- Bullet Speed -10%
- Reload Time +10%





#### Roots Card

Hi roots cool thx for the help

- Projectiles +5
- Ammunition +2
- Reload Time -15%
- Damage -40%
- Health -10%





#### Troll

Trollololol

- Damage -10%
- Reload Time +10%
- Health -10%
- Ammunition +1
- Bullet Speed +100%
- Projectiles +1
- Attack Speed -25%
- Bounces +1
- Bursts +2
- Time Between Bullets -1.1 seconds





#### one

A wish version of all

- Damage +10%
- Health +10%
- Reload Time -10%
- Ammunition +1
- Projectiles +1
- Bursts +1
- Time Between Bullets -1 seconds
- Attack Speed +10%
- Bounces +1
- Bullet Speed +10%





#### OH Canada

Look here buddy 

- Damage +40%
- Health -20%
- Ammunition +3





#### Rounds Love

<3

- Health +30%
- Reload Time -20%
- Damage -15%





#### Merica

MERICA! FREK YEAH!

- Attack Speed +35%
- Health -40%
- Damage +20%
- Ammunition +17





#### Fast Ball

Throw your bullets like and MLB pro

- Ammunition -2
- Bullet Speed +90%
- Reload Time -10%





#### DMG Over Health

Give me 90% dmg for 90% health

- Damage +90%
- Health -90%





#### Health over DMG

All the health for less DMG

- Damage -65%
- Health +120%





#### more bounces

Every body JUMP!

- Bounces +5





#### Fun

Bring the fun to your friends 

- Projectiles +2
- Bursts +2
- Time Between Bullets -0.6 seconds
- Bullet Speed +50%


